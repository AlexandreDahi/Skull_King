package com.example.skullking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkullkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
